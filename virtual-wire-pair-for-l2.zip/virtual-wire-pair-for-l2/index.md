---
title: Virtual Wire Pair for L2
parent: Fortigate Environment
nav_order: 1
---

## Table of contents
{: .no_toc .text-delta }

1. TOC
{:toc}

---

## Overview
```
         -----------------------------
        |         Fortigate           |
port 2  |⇄---------(forward)--------⇄| port 3
        |                             |
         -----------------------------
```

## Interface setting
```
config system interface
    edit "port2"
        set vdom "root"
        set l2forward enable
        set type physical
        set device-identification enable
        set snmp-index 2
    next
end
config system interface
    edit "port3"
        set vdom "root"
        set l2forward enable
        set type physical
        set device-identification enable
        set snmp-index 3
    next
end
```

## Virtual Wire Pair
```
config system virtual-wire-pair
    edit "VWP"
        set member "port2" "port3"
    next
end
```

## Firewall Policy
```
config firewall policy
    edit 1
        set name "VWP-Policy"
        set srcintf "port2" "port3"
        set dstintf "port2" "port3"
        set action accept
        set srcaddr "all"
        set dstaddr "all"
        set schedule "always"
        set service "ALL"
        set utm-status enable
        set application-list "L2-Sensor"
    next
end
```

## Firewall Interface Policy
```
config firewall interface-policy
    edit 1
        set interface "port3"
        set srcaddr "all"
        set dstaddr "all"
        set service "ALL"
        set application-list-status enable
        set application-list "L2-Sensor"
    next
end
```

## Custom AppCtrl signature
```
config application custom
    edit "Profinet.General"
        set comment ''
        set signature "F-SBID( --attack_id 4297; --name \"Profinet.General\"; --default_action pass; --ethertype 0x8892; --deep_ctrl dpi_log,\"Vendor=Profinet, Model=AAA\"; --scan-range 2k,none; --app_cat 33;)"
        set category 33
    next
end
```

### Application Sensor
```
config application list
    edit "L2-Sensor"
        set other-application-log enable
        config entries
            edit 1
                set application 4297
                set action pass
            next
            edit 2
                set category 2 6
            next
        end
    next 
end
```

### Include OT signatures
```
config ips global
    set exclude-signatures none
end
```

### Miscellaneous
sniff on port to verify packet receive
```
diagnose sniffer packet port3 '!arp' 3 0
```
Replay pcap, if know name of interface, replace the embeded script with interface name. 
```
sudo tcpreplay -i "$(ip route | awk '/default/ {print $5; exit}')" profinet_rt.pcapng
```
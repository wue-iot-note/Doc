---
title: IoT Resource
nav_order: 3
---

# Search Engine Cheatsheet
{: .no_toc }

## Table of contents
{: .no_toc .text-delta }

1. TOC
{:toc}

---
### Device info
[electronics device database](https://device.report/)<br>

### Online Pcap resource
[cloudshark.org](https://www.cloudshark.org/captures)<br>
```
### google dork search query
"DHCP" site:"cloudshark.org"
```
[Wireshark SampleCaptures](https://wiki.wireshark.org/samplecaptures)<br>
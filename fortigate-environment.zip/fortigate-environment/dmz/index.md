---
title: DMZ
parent: Fortigate Environment
nav_order: 1
---

## Table of contents
{: .no_toc .text-delta }

1. TOC
{:toc}

---

## Overview
```
 Internet
     |
   port1 (172.168.10.5)
 -----------
| Fortigate | ---- port 3 -- DMZ --- PC2
 -----------     (10.0.0.1)       (10.0.0.3) 
   port2 (192.168.1.1)
     |
  Internal
     |
    PC1 (192.168.1.10)

```

## Interface setting
```
config system interface
    edit "port1"
        set vdom "root"
        set ip 172.168.10.5 255.255.255.0
        set allowaccess ping https ssh http fgfm
        set type physical
        set alias "Internet"
        set lldp-reception enable
        set role wan
        set snmp-index 1
    next
    edit "port2"
        set vdom "root"
        set ip 192.168.1.1 255.255.255.0
        set allowaccess ping https ssh http telnet
        set type physical
        set alias "Internal"
        set device-identification enable
        set snmp-index 2
    next
    edit "port3"
        set vdom "root"
        set ip 10.0.0.1 255.255.255.0
        set allowaccess ping
        set type physical
        set alias "DMZ"
        set device-identification enable
        set snmp-index 3
    next
end
```

## Virtual IP
```
config firewall vip
    edit "DMZ web server access"
        set uuid aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa
        set extip 172.168.10.5
        set mappedip "10.0.0.3"
        set extintf "port2"
        set portforward enable
        set extport 8080
        set mappedport 8080
    next
end
```

## Firewall Policy
```
config firewall policy
    edit 1
        set name "InternetAccess"
        set uuid aaaaaaaa-aaaa-aaaa-aaaaaaaaaaaaaaaaa
        set srcintf "port2"
        set dstintf "port1"
        set action accept
        set srcaddr "all"
        set dstaddr "all"
        set schedule "always"
        set service "ALL"
        set nat enable
    next
    edit 2
        set name "Internal-to-DMZ"
        set uuid aaaaaaaa-aaaa-aaaa-aaaaaaaaaaaaaaaaa
        set srcintf "port2"
        set dstintf "port3"
        set action accept
        set srcaddr "all"
        set dstaddr "DMZ web server access"
        set schedule "always"
        set service "ALL"
        set utm-status enable
        set application-list "default"
        set nat enable
    next
end
```

## Simulation script
```
|___ case
|     |___ Google_Home.txt
|
|___ script.py
# Google_Home.txt is copied from wireshark HTTP->Follow->HTTP Stream
```

### script
```
import argparse
import socket
import datetime
from pathlib import Path

def load_request_response(filename: str):
    """Load client request and server response template from a file."""
    text = Path(filename).read_text(encoding="utf-8")
    parts = text.split("\n\n", 1)  # split request vs response
    if len(parts) != 2:
        raise ValueError("File must contain client request and server response separated by a blank line")

    client_request = parts[0].strip() + "\r\n\r\n"  # ensure CRLF ending
    server_response = parts[1].strip()

    return client_request, server_response


def inject_dynamic_date(response_template: str) -> str:
    """Replace or insert Date header with current time."""
    lines = response_template.splitlines()
    new_lines = []
    date_str = datetime.datetime.now(datetime.UTC).strftime("%a, %d %b %Y %H:%M:%S GMT")

    replaced = False
    for line in lines:
        if line.lower().startswith("date:"):
            new_lines.append(f"Date: {date_str}")
            replaced = True
        else:
            new_lines.append(line)

    if not replaced:
        # insert Date header after status line
        new_lines.insert(1, f"Date: {date_str}")

    return "\r\n".join(new_lines) + "\r\n"


def run_server(port: int, server_response_template: str):
    """Simple TCP server that returns a fixed HTTP response."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", port))
        s.listen(1)
        print(f"[SERVER] Listening on 0.0.0.0:{port} ...")

        while True:
            conn, addr = s.accept()
            with conn:
                print(f"[SERVER] Connection from {addr}")
                request = conn.recv(4096).decode(errors="ignore")
                print(f"[SERVER] Received request:\n{request.strip()}\n")

                # Update Date dynamically
                response = inject_dynamic_date(server_response_template)
                conn.sendall(response.encode())
                print("[SERVER] Sent response.\n")


def run_client(ip: str, port: int, client_request: str):
    """Simple TCP client that sends fixed HTTP request and prints the response."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        print(f"[CLIENT] Connected to {ip}:{port}")
        s.sendall(client_request.encode())
        print(f"[CLIENT] Sent request:\n{client_request.strip()}\n")

        response = b""
        while True:
            chunk = s.recv(4096)
            if not chunk:
                break
            response += chunk

        print(f"[CLIENT] Received response:\n{response.decode(errors='ignore')}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="HTTP client/server script with file-based request/response")
    parser.add_argument("--client", action="store_true", help="Run as client")
    parser.add_argument("--server", action="store_true", help="Run as server")
    parser.add_argument("--ip", type=str, help="Server IP (for client mode)")
    parser.add_argument("--port", type=int, required=True, help="Port for client/server")
    parser.add_argument("--file", type=str, required=True, help="File containing request and response")

    args = parser.parse_args()

    client_request, server_response = load_request_response(args.file)

    if args.server:
        run_server(args.port, server_response)
    elif args.client:
        if not args.ip:
            parser.error("--ip is required for client mode")
        run_client(args.ip, args.port, client_request)
    else:
        parser.error("Must specify either --client or --server")
```

### Google_Home.txt (example)
```
GET /setup/eureka_info?options=detail&params=version,name,build_info,device_info,net,wifi,setup,settings,opt_in,opencast,multizone,audio,detail,night_mode_params,tts_volume,user_eq,room_equalizer HTTP/1.1
Host: 192.168.1.107:8008
Origin: https://www.google.com
Accept: */*
User-Agent: com.google.Chromecast/2.43 iPhone/12.5.4 hw/iPhone7_1
Accept-Language: en-ca
Accept-Encoding: gzip, deflate
Connection: keep-alive


HTTP/1.1 200 OK
Access-Control-Allow-Headers:Content-Type
Cache-Control:no-cache
Access-Control-Allow-Origin:https://www.google.com
Content-Length:1289
Content-Type:application/json

{"bssid":"AA:AA:AA:AA:AA:AA","build_version":"282045","cast_build_revision":"1.56.282045","closed_caption":{},"connected":true,"ethernet_connected":false,"has_update":false,"hotspot_bssid":"AA:AA:AA:AA:AA:AA","ip_address":"192.168.1.107","locale":"en-CA","location":{"country_code":"CA","latitude":255.0,"longitude":255.0},"mac_address":"AA:AA:AA:AA:AA:AA","name":"...... speaker","noise_level":-88,"opt_in":{"crash":false,"opencast":false,"stats":false},"public_key":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","release_track":"stable-channel","setup_state":60,"setup_stats":{"historically_succeeded":true,"num_check_connectivity":0,"num_connect_wifi":0,"num_connected_wifi_not_saved":0,"num_initial_eureka_info":0,"num_obtain_ip":0},"signal_level":-22,"ssdp_udn":"AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA","ssid":"OpenTest","time_format":1,"timezone":"America/Vancouver","tos_accepted":true,"uptime":876.222796,"version":12,"wpa_configured":true,"wpa_id":0,"wpa_state":10}
```